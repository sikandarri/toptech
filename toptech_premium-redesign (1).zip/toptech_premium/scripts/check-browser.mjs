import { chromium } from "playwright";
import { spawn } from "node:child_process";
import assert from "node:assert/strict";
const server = spawn(process.execPath, ["server/index.js"], { stdio: "pipe" });
await new Promise((resolve, reject) => {
  server.stdout.once("data", resolve);
  server.once("error", reject);
});
let browser;
try {
  browser = await chromium.launch({ headless: true });
  const page = await browser.newPage({
    viewport: { width: 1366, height: 768 },
  });
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await page.goto("http://127.0.0.1:3000");
  await page.waitForTimeout(1200);
  assert.equal(await page.locator("article.project").count(), 4);

  // FAQ: first item open by default, clicking another swaps it.
  const faq = page.locator("#faq");
  await faq.scrollIntoViewIfNeeded();
  const q2 = faq.getByRole("button", { name: /handle both the website/ });
  await q2.click();
  assert.equal(await q2.getAttribute("aria-expanded"), "true");

  // Privacy link opens the disclosure.
  await page.getByRole("link", { name: "Privacy details" }).click();
  assert.equal(await page.locator("#privacy").evaluate((d) => d.open), true);

  // Inquiry form shows honest feedback when the database is unavailable.
  await page.getByLabel("Your name").fill("Website Test");
  await page.getByLabel("Email address").fill("test@example.com");
  await page
    .getByLabel("A little about your idea")
    .fill("I would like a website for my new business.");
  await page.locator("input[name=consent]").check();
  await page
    .getByRole("button", { name: "Let’s talk about your project" })
    .click();
  await page.getByRole("alert").waitFor();
  assert.match(
    await page.getByRole("alert").innerText(),
    /temporarily unavailable/,
  );
  const api = await page.request.post("http://127.0.0.1:3000/api/inquiries", {
    data: { name: "bad" },
  });
  assert.equal(api.status(), 400);

  for (const width of [390, 768, 1366]) {
    await page.setViewportSize({ width, height: 844 });
    await page.goto("http://127.0.0.1:3000");
    await page.waitForTimeout(900);
    assert.equal(
      await page.evaluate(
        () => document.documentElement.scrollWidth <= innerWidth,
      ),
      true,
      `Overflow at ${width}`,
    );
    if (width === 390) {
      await page.getByRole("button", { name: "Open navigation" }).click();
      await page
        .getByRole("navigation", { name: "Mobile navigation" })
        .getByRole("link", { name: /Work/ })
        .click();
      await page.waitForTimeout(800);
      assert.equal(
        await page
          .getByRole("button", { name: "Open navigation" })
          .getAttribute("aria-expanded"),
        "false",
      );
    }
  }
  assert.deepEqual(errors, []);
  console.log(
    "Browser QA passed: 4 live projects, FAQ, privacy disclosure, honest form feedback, mobile menu, no overflow at 390/768/1366.",
  );
} finally {
  await browser?.close();
  server.kill();
}
