import { getPool } from "../server/db.js";
const pool = getPool();
try {
  const [rows] = await pool.query(
    "SELECT id,name,email,service,budget,message,created_at FROM inquiries ORDER BY id DESC LIMIT 100",
  );
  console.log(JSON.stringify(rows, null, 2));
} finally {
  await pool.end();
}
