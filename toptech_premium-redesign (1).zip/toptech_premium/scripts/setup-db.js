import { getPool } from "../server/db.js";
const pool = getPool();
try {
  await pool.query(
    `CREATE TABLE IF NOT EXISTS inquiries (id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,name VARCHAR(100) NOT NULL,email VARCHAR(254) NOT NULL,service VARCHAR(100) NOT NULL,budget VARCHAR(100) NOT NULL,message TEXT NOT NULL,consent BOOLEAN NOT NULL,created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,INDEX idx_created_at(created_at)) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci`,
  );
  console.log("Inquiry table is ready.");
} finally {
  await pool.end();
}
