import { useEffect, useState } from "react";
import { MotionConfig, motion, useScroll, useSpring } from "motion/react";
import Lenis from "lenis";
import Nav from "./components/sections/Nav";
import Hero from "./components/sections/Hero";
import TechMarquee from "./components/sections/Marquee";
import Work from "./components/sections/Work";
import Services from "./components/sections/Services";
import Growth from "./components/sections/Growth";
import Approach from "./components/sections/Approach";
import Faq from "./components/sections/Faq";
import Contact from "./components/sections/Contact";
import Footer from "./components/sections/Footer";

function useSmoothScroll() {
  const [lenis, setLenis] = useState(null);
  useEffect(() => {
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const instance = new Lenis({
      autoRaf: true,
      lerp: 0.1,
      anchors: { offset: -88 },
    });
    setLenis(instance);
    return () => instance.destroy();
  }, []);
  return lenis;
}

// Links to #privacy should open the disclosure, not just scroll to it.
function usePrivacyAnchor() {
  useEffect(() => {
    const onClick = (e) => {
      const a = e.target.closest?.('a[href="#privacy"]');
      if (!a) return;
      const d = document.getElementById("privacy");
      if (d) d.open = true;
    };
    document.addEventListener("click", onClick);
    return () => document.removeEventListener("click", onClick);
  }, []);
}

export default function App() {
  const lenis = useSmoothScroll();
  usePrivacyAnchor();
  const { scrollYProgress } = useScroll();
  const progress = useSpring(scrollYProgress, { stiffness: 120, damping: 30 });

  return (
    <MotionConfig reducedMotion="user">
      <a className="skip-link" href="#main">Skip to content</a>
      <motion.div className="scroll-progress" style={{ scaleX: progress }} aria-hidden="true" />
      <Nav lenis={lenis} />
      <main id="main">
        <Hero />
        <TechMarquee />
        <Work />
        <Services />
        <Growth />
        <Approach />
        <Faq />
        <Contact />
      </main>
      <Footer />
      <div className="grain" aria-hidden="true" />
    </MotionConfig>
  );
}
