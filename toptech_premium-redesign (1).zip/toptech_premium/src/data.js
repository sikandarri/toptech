import {
  Code2,
  Layers,
  BarChart3,
  MousePointer2,
  Database,
} from "lucide-react";

export const nav = [
  ["Work", "work"],
  ["Services", "services"],
  ["Approach", "approach"],
  ["FAQ", "faq"],
];

export const projects = [
  {
    id: "vekzor",
    name: "VEKZOR",
    type: "Commerce",
    category: "E-commerce",
    label: "A sharper digital storefront.",
    description:
      "A sportswear storefront with product collections, a rotating hero showcase, and a clean shopping experience.",
    features: [
      "Product collection browsing",
      "Responsive storefront",
      "Admin-managed content",
    ],
    tech: ["React", "Node.js", "MySQL"],
    theme: "sport",
    accent: "#C6F432",
    url: "https://mediumturquoise-gull-115635.hostingersite.com/",
    previewSources: [
      "https://image.thum.io/get/width/1440/crop/900/noanimate/https://mediumturquoise-gull-115635.hostingersite.com/",
    ],
  },
  {
    id: "iqra",
    name: "Iqra Signature Salon",
    type: "Brand websites",
    category: "Beauty & lifestyle",
    label: "Luxury, down to the last detail.",
    description:
      "A digital home for a bridal studio and spa, bringing treatments, bridal work, and the salon experience together.",
    features: [
      "Service and treatment showcase",
      "Client-work gallery",
      "Immersive salon tour",
    ],
    tech: ["React", "Express", "MySQL"],
    theme: "salon",
    accent: "#D9B779",
    url: "https://silver-ferret-752198.hostingersite.com/",
    previewSources: [
      "https://image.thum.io/get/width/1440/crop/900/noanimate/https://silver-ferret-752198.hostingersite.com/",
    ],
  },
  {
    id: "deutsch",
    name: "Deutsch Daily",
    type: "Web applications",
    category: "Education platform",
    label: "A little progress. Every day.",
    description:
      "A German learning platform that organizes vocabulary, lessons, and exam preparation into a guided learning experience.",
    features: [
      "Structured daily learning",
      "Vocabulary and practice",
      "Student progress",
    ],
    tech: ["React", "Node.js", "Database"],
    theme: "learn",
    accent: "#8EA2FF",
    url: "https://palevioletred-seal-607183.hostingersite.com/",
    previewSources: [
      "https://image.thum.io/get/width/1440/crop/900/noanimate/https://palevioletred-seal-607183.hostingersite.com/",
    ],
  },
  {
    id: "grand",
    name: "Grand Cafe",
    type: "Brand websites",
    category: "Food & hospitality",
    label: "Good food. A great first impression.",
    description:
      "A restaurant website designed to make browsing food, exploring the menu, and choosing a favourite feel effortless.",
    features: [
      "Digital food menu",
      "Category-based browsing",
      "Mobile-first experience",
    ],
    tech: ["React", "Express", "Responsive UI"],
    theme: "cafe",
    accent: "#F0A86B",
    url: "https://ghostwhite-beaver-182957.hostingersite.com/",
    previewSources: [
      "https://s.wordpress.com/mshots/v1/https%3A%2F%2Fghostwhite-beaver-182957.hostingersite.com%2F?w=1440",
      "https://image.thum.io/get/width/1440/crop/900/wait/5/noanimate/https://ghostwhite-beaver-182957.hostingersite.com/",
      "/portfolio/grand-cafe-fallback.webp",
    ],
  },
];

export const services = [
  {
    icon: Code2,
    n: "01",
    title: "Websites that mean business.",
    text: "Distinctive business websites, landing pages, and e-commerce experiences. Fast to load. Easy to use.",
    tags: ["Business websites", "E-commerce", "Landing pages"],
  },
  {
    icon: Layers,
    n: "02",
    title: "Software built around you.",
    text: "Turn your workflow or product idea into a dependable web application, from the first screen to the database.",
    tags: ["MERN applications", "Admin dashboards", "API integrations"],
  },
  {
    icon: BarChart3,
    n: "03",
    title: "Give your next launch reach.",
    text: "Connect your website with thoughtful Meta and Instagram campaigns, creative testing, and clear reporting.",
    tags: ["Meta & Instagram ads", "Ad creative", "Conversion tracking"],
  },
];

export const layers = [
  { name: "Experience", sub: "React · Tailwind CSS", Icon: MousePointer2 },
  { name: "Application", sub: "Node.js · Express", Icon: Code2 },
  { name: "Data", sub: "MySQL · MongoDB", Icon: Database },
  { name: "Growth", sub: "Meta · Instagram Ads", Icon: BarChart3 },
];

export const tech = [
  "React",
  "Node.js",
  "Express",
  "MongoDB",
  "MySQL",
  "Tailwind CSS",
  "Framer Motion",
  "REST APIs",
  "Meta Ads",
  "Vite",
];

export const process = [
  [
    "Discover",
    "We get to know your business, your audience, and the problem worth solving.",
  ],
  [
    "Design",
    "We shape the structure and visual direction around the people who will use it.",
  ],
  [
    "Develop",
    "We build the experience, connect the backend, and test the details that matter.",
  ],
  [
    "Deliver",
    "We launch, hand over the code, and help you understand how to run your website.",
  ],
];

export const faqs = [
  [
    "What kind of businesses do you work with?",
    "We build for service businesses, salons, restaurants, retail brands, educators, and founders turning a new idea into a web application.",
  ],
  [
    "Can you handle both the website and advertising?",
    "Yes. We can plan the website, landing pages, and Meta or Instagram campaigns together. Advertising spend is separate from development and campaign management fees.",
  ],
  [
    "Will I own my website and source code?",
    "Yes. Your project handover includes the source code and deployment guidance. Any third-party subscriptions, assets, and licenses are explained as part of the scope.",
  ],
  [
    "How much does a project cost?",
    "Every project has a different scope. Tell us what you need and we will propose the deliverables, timeline, and price before work begins.",
  ],
  [
    "Can you improve an existing website?",
    "Yes. We can review your existing website and discuss design improvements, performance, new features, or a rebuild if that is the right fit.",
  ],
];

// Must match the enums in server/validation.js exactly.
export const serviceOptions = [
  "Website development",
  "Full-stack application",
  "E-commerce website",
  "Meta & Instagram ads",
  "Website + advertising",
];
export const budgetOptions = [
  "Let’s discuss",
  "Under PKR 100,000",
  "PKR 100,000–300,000",
  "PKR 300,000+",
];

export const ease = [0.22, 1, 0.36, 1];
