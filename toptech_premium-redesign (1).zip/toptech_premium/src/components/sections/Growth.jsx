import { useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";
import { ArrowUpRight, BarChart3, Camera, MousePointer2, ShieldCheck } from "lucide-react";
import { ease } from "../../data";
import { Eyebrow, FadeIn, Magnetic, RevealText } from "../ui/primitives";

const steps = [
  ["Make the right impression.", "Creative strategy & ad design", Camera],
  ["Build a better destination.", "Focused, responsive landing pages", MousePointer2],
  ["Learn. Refine. Repeat.", "Conversion tracking & reporting", BarChart3],
];

export default function Growth() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 0.8", "end 0.6"] });
  const line = useTransform(scrollYProgress, [0, 1], [0, 1]);

  return (
    <section id="advertising" className="section growth">
      <div className="growth-bg" aria-hidden="true" />
      <div className="container growth-grid">
        <div className="growth-copy">
          <Eyebrow>Development meets digital growth</Eyebrow>
          <h2 className="display-2 mt-6">
            <RevealText text="A great website deserves the" inView className="block" />
            <RevealText text="right audience." inView delay={0.15} className="block serif-accent gradient-text" />
          </h2>
          <FadeIn delay={0.1}>
            <p className="section-lead">
              Bring the full journey together. We plan Meta and Instagram
              campaigns that lead people from the first impression to a clear
              next step.
            </p>
          </FadeIn>
          <FadeIn delay={0.2} className="platforms">
            <span><span className="meta-symbol" aria-hidden="true">∞</span> Meta Ads</span>
            <span className="platforms-sep" aria-hidden="true" />
            <span><Camera size={18} /> Instagram Ads</span>
          </FadeIn>
          <FadeIn delay={0.3}>
            <Magnetic>
              <a href="#contact" className="btn btn-light btn-lg">
                Plan your campaign <span className="btn-icon"><ArrowUpRight size={18} /></span>
              </a>
            </Magnetic>
          </FadeIn>
        </div>

        <div ref={ref} className="journey">
          <div className="journey-head">
            <span className="mono">The connected customer journey</span>
            <ArrowUpRight size={16} className="opacity-50" />
          </div>
          <div className="journey-steps">
            <div className="journey-track" aria-hidden="true">
              <motion.span style={{ scaleY: line }} />
            </div>
            {steps.map(([title, sub, Icon], i) => (
              <motion.div
                key={title}
                className="journey-step"
                initial={{ opacity: 0, x: 24 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, amount: 0.6 }}
                transition={{ duration: 0.7, delay: i * 0.12, ease }}
              >
                <span className="journey-no mono">0{i + 1}</span>
                <div className="flex-1">
                  <strong>{title}</strong>
                  <p>{sub}</p>
                </div>
                <span className="journey-icon"><Icon size={18} /></span>
              </motion.div>
            ))}
          </div>
          <div className="journey-foot">
            <ShieldCheck size={16} /> Clear goals. Honest reporting. No inflated promises.
          </div>
        </div>
      </div>
    </section>
  );
}
