import { motion } from "motion/react";
import { ArrowUpRight, FileCode2, Folder, Plus } from "lucide-react";
import { services, ease } from "../../data";
import Spotlight from "../ui/Spotlight";
import { FadeIn, SectionHeading } from "../ui/primitives";

function WebVisual() {
  return (
    <div className="sv sv-web" aria-hidden="true">
      <div className="sv-browser">
        <div className="sv-browser-bar"><i /><i /><i /><span /></div>
        <div className="sv-browser-body">
          <div className="sv-nav"><b /><span /><span /><span /></div>
          <div className="sv-hero-block">
            <span className="w-3/4" />
            <span className="w-1/2" />
            <em />
          </div>
          <div className="sv-cards">
            <span /><span /><span />
          </div>
        </div>
      </div>
      <div className="sv-floating sv-floating-a">Fast to load</div>
      <div className="sv-floating sv-floating-b">Mobile first</div>
    </div>
  );
}

function CodeVisual() {
  const lines = [
    [["k", "const "], ["v", "app"], ["p", " = "], ["f", "express"], ["p", "();"]],
    [["k", "app"], ["p", "."], ["f", "post"], ["p", "("], ["s", "'/api/orders'"], ["p", ", "], ["v", "auth"], ["p", ","]],
    [["p", "  "], ["k", "async "], ["p", "(req, res) => {"]],
    [["p", "    "], ["k", "const "], ["v", "order"], ["p", " = "], ["k", "await "], ["f", "db"], ["p", ".create(req.body);"]],
    [["p", "    "], ["v", "res"], ["p", "."], ["f", "status"], ["p", "(201)."], ["f", "json"], ["p", "(order);"]],
    [["p", "});"]],
  ];
  return (
    <div className="sv sv-code" aria-hidden="true">
      <div className="sv-code-head"><span>server/routes.js</span><span className="mono">200 OK</span></div>
      <pre>
        {lines.map((l, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -8 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 + i * 0.09, duration: 0.5, ease }}
          >
            <span className="ln">{i + 1}</span>
            {l.map(([c, t], j) => <span key={j} className={`tk-${c}`}>{t}</span>)}
            {i === lines.length - 1 && <span className="caret" />}
          </motion.div>
        ))}
      </pre>
    </div>
  );
}

function GrowthVisual() {
  const bars = [28, 40, 34, 56, 48, 72, 64, 90];
  return (
    <div className="sv sv-growth" aria-hidden="true">
      <div className="sv-growth-head">
        <span>Campaign → Landing → Lead</span>
      </div>
      <div className="sv-bars">
        {bars.map((h, i) => (
          <motion.span
            key={i}
            initial={{ scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.15 + i * 0.07, duration: 0.8, ease }}
            style={{ height: `${h}%` }}
          />
        ))}
      </div>
    </div>
  );
}

function HandoverVisual() {
  const tree = [
    [0, Folder, "your-project"],
    [1, Folder, "src"],
    [2, FileCode2, "App.jsx"],
    [1, Folder, "server"],
    [2, FileCode2, "index.js"],
    [1, FileCode2, "README.md"],
  ];
  return (
    <div className="sv sv-tree" aria-hidden="true">
      {tree.map(([d, Icon, name], i) => (
        <motion.div
          key={i}
          style={{ paddingLeft: d * 18 }}
          initial={{ opacity: 0, y: 6 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.1 + i * 0.07, duration: 0.5, ease }}
        >
          <Icon size={14} /> {name}
        </motion.div>
      ))}
      <span className="sv-tree-badge">Yours. 100%.</span>
    </div>
  );
}

const visuals = [WebVisual, CodeVisual, GrowthVisual];

function ServiceCard({ s, Visual, className, delay }) {
  return (
    <FadeIn delay={delay} className={className}>
      <Spotlight as="article" className="bento-card h-full">
        <Visual />
        <div className="bento-body">
          <div className="bento-top">
            <span className="bento-icon"><s.icon size={18} /></span>
            <span className="mono text-fg/40">/{s.n}</span>
          </div>
          <h3>{s.title}</h3>
          <p>{s.text}</p>
          <ul className="bento-tags">
            {s.tags.map((t) => <li key={t}><Plus size={12} />{t}</li>)}
          </ul>
        </div>
      </Spotlight>
    </FadeIn>
  );
}

export default function Services() {
  return (
    <section id="services" className="section services">
      <div className="container">
        <SectionHeading
          index="02"
          label="What we do"
          title="From first thought"
          accent="to what’s next."
          intro="Design, development, and digital growth. The right skills for every stage of your business."
        />
        <div className="bento">
          <ServiceCard s={services[0]} Visual={visuals[0]} className="bento-a" delay={0} />
          <ServiceCard s={services[1]} Visual={visuals[1]} className="bento-b" delay={0.08} />
          <ServiceCard s={services[2]} Visual={visuals[2]} className="bento-c" delay={0.08} />
          <FadeIn delay={0.16} className="bento-d">
            <Spotlight as="article" className="bento-card h-full">
              <HandoverVisual />
              <div className="bento-body">
                <div className="bento-top">
                  <span className="bento-icon"><FileCode2 size={18} /></span>
                  <span className="mono text-fg/40">/04</span>
                </div>
                <h3>Built to hand over.</h3>
                <p>
                  Your handover includes the source code and deployment guidance.
                  No lock-in, no mystery — just a project you own and understand.
                </p>
                <a href="#contact" className="link-arrow">
                  Let’s discuss your project <ArrowUpRight size={15} />
                </a>
              </div>
            </Spotlight>
          </FadeIn>
        </div>
      </div>
    </section>
  );
}
