import { tech } from "../../data";

export default function TechMarquee() {
  const row = [...tech, ...tech];
  return (
    <section className="marquee-section" aria-label="Technologies we work with">
      <div className="container marquee-head">
        <span className="mono">The tools</span>
        <span className="mono text-fg/40">/ the possibilities</span>
      </div>
      <div className="marquee" role="list">
        <div className="marquee-track">
          {row.map((t, i) => (
            <span className="marquee-item" key={i} role="listitem" aria-hidden={i >= tech.length}>
              {t}
              <span className="marquee-star" aria-hidden="true">✦</span>
            </span>
          ))}
        </div>
      </div>
    </section>
  );
}
