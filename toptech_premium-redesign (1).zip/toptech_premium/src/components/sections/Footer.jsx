import { motion } from "motion/react";
import { ArrowUp, ArrowUpRight } from "lucide-react";
import { nav, services, ease } from "../../data";
import { Brand } from "../ui/primitives";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-cta">
          <p className="display-3">
            Have an idea?{" "}
            <a href="#contact" className="serif-accent gradient-text footer-cta-link">
              Let’s talk <ArrowUpRight className="inline" />
            </a>
          </p>
        </div>
        <div className="footer-grid">
          <div className="footer-brand">
            <Brand />
            <p>Thoughtfully designed.<br />Carefully developed.</p>
          </div>
          <div>
            <h4 className="mono">Navigate</h4>
            <ul>
              {[...nav, ["Contact", "contact"]].map(([l, id]) => (
                <li key={id}><a href={`#${id}`}>{l}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="mono">Services</h4>
            <ul>
              {services.flatMap((s) => s.tags.slice(0, 2)).map((t) => (
                <li key={t}><a href="#services">{t}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="mono">Studio</h4>
            <ul>
              <li><span>Pakistan</span></li>
              <li><span>Working worldwide</span></li>
              <li>
                <details id="privacy" className="privacy">
                  <summary>Privacy</summary>
                  <p>
                    We collect the name, email, project details, and preferences
                    you submit to respond to your inquiry. Submissions are stored
                    in our project inquiry database. We do not sell your
                    information. To ask about or request deletion of an inquiry,
                    submit a new request using the same email address. This
                    website does not use advertising trackers by default.
                  </p>
                </details>
              </li>
            </ul>
          </div>
        </div>
      </div>

      <motion.div
        className="footer-wordmark"
        aria-hidden="true"
        initial={{ opacity: 0, y: 60 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 1.2, ease }}
      >
        TOP TECH
      </motion.div>

      <div className="container footer-bottom">
        <span>© {new Date().getFullYear()} Top Tech Development</span>
        <span className="hidden sm:inline">Pakistan / Working worldwide</span>
        <a href="#home" className="back-top">
          Back to top <ArrowUp size={14} />
        </a>
      </div>
    </footer>
  );
}
