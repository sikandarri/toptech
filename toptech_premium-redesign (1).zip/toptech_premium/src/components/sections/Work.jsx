import { useEffect, useState } from "react";
import { ArrowUpRight, Check } from "lucide-react";
import { projects } from "../../data";
import { useMediaQuery } from "../../lib/hooks";
import StackingCards, { StackingCardItem } from "../ui/StackingCards";
import { Magnetic, SectionHeading } from "../ui/primitives";

function FallbackArt({ project }) {
  const t = project.theme;
  return (
    <div className={`fallback-art fa-${t}`} aria-hidden="true">
      {t === "sport" && (
        <div className="fa-sport">VEKZOR<small>MOVE BEYOND.</small></div>
      )}
      {t === "salon" && (
        <div className="fa-salon"><span>IS</span><strong>Iqra Signature</strong><em>BRIDAL STUDIO &amp; SPA</em></div>
      )}
      {t === "learn" && (
        <div className="fa-learn">Hallo,<br />new possibilities<small>Deutsch Daily</small></div>
      )}
      {t === "cafe" && (
        <div className="fa-cafe">Grand<br /><em>Cafe.</em></div>
      )}
    </div>
  );
}

function Preview({ project }) {
  const sources = project.previewSources || [];
  const [idx, setIdx] = useState(0);
  const [loaded, setLoaded] = useState(false);
  useEffect(() => {
    setIdx(0);
    setLoaded(false);
  }, [project.id]);
  const host = new URL(project.url).hostname;

  return (
    <a
      href={project.url}
      target="_blank"
      rel="noopener noreferrer"
      className="browser"
      aria-label={`Open ${project.name} live website (opens in a new tab)`}
    >
      <div className="browser-bar">
        <span className="browser-dots" aria-hidden="true"><i /><i /><i /></span>
        <span className="browser-url">{host}</span>
        <span className="browser-live"><span className="pulse-dot" />Live</span>
      </div>
      <div className="browser-view">
        <FallbackArt project={project} />
        {sources[idx] && (
          <img
            key={`${project.id}-${idx}`}
            src={sources[idx]}
            alt={`${project.name} homepage preview`}
            loading="lazy"
            decoding="async"
            referrerPolicy="no-referrer"
            className={loaded ? "is-loaded" : ""}
            onLoad={() => setLoaded(true)}
            onError={() => idx < sources.length - 1 && setIdx((i) => i + 1)}
          />
        )}
        <span className="browser-cta" aria-hidden="true">
          Visit site <ArrowUpRight size={16} />
        </span>
      </div>
    </a>
  );
}

function ProjectCard({ project, index, total }) {
  return (
    <article className="project" style={{ "--accent": project.accent }}>
      <div className="project-glow" aria-hidden="true" />
      <div className="project-info">
        <div className="project-meta">
          <span className="mono">{String(index + 1).padStart(2, "0")} / {String(total).padStart(2, "0")}</span>
          <span className="project-cat">{project.category}</span>
        </div>
        <h3 className="project-name">{project.name}</h3>
        <p className="project-label serif-accent">{project.label}</p>
        <p className="project-desc">{project.description}</p>
        <ul className="project-features">
          {project.features.map((f) => (
            <li key={f}><Check size={15} /> {f}</li>
          ))}
        </ul>
        <div className="project-foot">
          <div className="chips">
            {project.tech.map((t) => <span key={t} className="chip">{t}</span>)}
          </div>
          <Magnetic>
            <a href={project.url} target="_blank" rel="noopener noreferrer" className="btn btn-light btn-sm">
              View live project <ArrowUpRight size={16} />
            </a>
          </Magnetic>
        </div>
      </div>
      <Preview project={project} />
    </article>
  );
}

export default function Work() {
  const stack = useMediaQuery("(min-width: 900px) and (min-height: 640px)");
  return (
    <section id="work" className="section work">
      <div className="container">
        <SectionHeading
          index="01"
          label="Selected work"
          title="Different businesses."
          accent="One thoughtful approach."
          intro="From storefronts to learning platforms, we build digital experiences around what makes each business different. Every project below is live — open it and look around."
        />
      </div>
      <StackingCards
        totalCards={projects.length}
        disabled={!stack}
        className={`container stack-list ${stack ? "is-stacking" : ""}`}
      >
        {projects.map((p, i) => (
          <StackingCardItem key={p.id} index={i}>
            <ProjectCard project={p} index={i} total={projects.length} />
          </StackingCardItem>
        ))}
      </StackingCards>
    </section>
  );
}
