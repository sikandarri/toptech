import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useScroll, useSpring, useTransform } from "motion/react";
import { ArrowDown, ArrowUpRight } from "lucide-react";
import { layers, ease } from "../../data";
import { Magnetic, RevealText } from "../ui/primitives";
import { useMediaQuery, usePrefersReducedMotion } from "../../lib/hooks";

function PlateUI({ index }) {
  if (index === 0)
    return (
      <div className="plate-ui">
        <div className="pu-bar"><i /><i /><i /></div>
        <div className="pu-hero" />
        <div className="pu-row"><span /><span /><span /></div>
      </div>
    );
  if (index === 1)
    return (
      <div className="plate-ui pu-code">
        {[72, 48, 86, 38, 64, 52].map((w, i) => (
          <span key={i} style={{ width: `${w}%`, marginLeft: i % 3 ? 14 : 0 }} />
        ))}
      </div>
    );
  if (index === 2)
    return (
      <div className="plate-ui pu-data">
        {Array.from({ length: 12 }).map((_, i) => (
          <span key={i} />
        ))}
      </div>
    );
  return (
    <div className="plate-ui pu-chart">
      {[34, 52, 44, 70, 62, 88].map((h, i) => (
        <span key={i} style={{ height: `${h}%` }} />
      ))}
    </div>
  );
}

function LayerStack() {
  const reduced = usePrefersReducedMotion();
  const [active, setActive] = useState(0);
  const [touched, setTouched] = useState(false);
  const ref = useRef(null);
  const mx = useMotionValue(0);
  const my = useMotionValue(0);
  const rx = useSpring(useTransform(my, [-0.5, 0.5], [64, 50]), { stiffness: 120, damping: 20 });
  const rz = useSpring(useTransform(mx, [-0.5, 0.5], [-50, -34]), { stiffness: 120, damping: 20 });

  useEffect(() => {
    if (touched || reduced) return;
    const t = setInterval(() => setActive((a) => (a + 1) % layers.length), 2600);
    return () => clearInterval(t);
  }, [touched, reduced]);

  const pick = (i) => {
    setTouched(true);
    setActive(i);
  };

  return (
    <div className="stack-visual">
      <div
        ref={ref}
        className="stack-scene"
        onPointerMove={(e) => {
          if (e.pointerType === "touch") return;
          const b = ref.current.getBoundingClientRect();
          mx.set((e.clientX - b.left) / b.width - 0.5);
          my.set((e.clientY - b.top) / b.height - 0.5);
        }}
        onPointerLeave={() => {
          mx.set(0);
          my.set(0);
        }}
        aria-hidden="true"
      >
        <div className="stack-glow" />
        <motion.div className="iso" style={{ rotateX: rx, rotateZ: rz }}>
          <div className="iso-floor" />
          {layers.map((l, i) => {
            const z = (layers.length - 1 - i) * 62;
            const isActive = active === i;
            return (
              <motion.div
                key={l.name}
                className={`plate plate-${i} ${isActive ? "is-active" : ""}`}
                initial={{ opacity: 0, z: z - 120 }}
                animate={{ opacity: 1, z: isActive ? z + 28 : z }}
                transition={{
                  opacity: { duration: 0.8, delay: 0.5 + (layers.length - i) * 0.12 },
                  z: { type: "spring", stiffness: 140, damping: 18, delay: touched ? 0 : 0.5 + (layers.length - i) * 0.12 },
                }}
                onMouseEnter={() => pick(i)}
              >
                <PlateUI index={i} />
                <span className="plate-tag">
                  <l.Icon size={12} /> {l.name}
                </span>
              </motion.div>
            );
          })}
        </motion.div>
      </div>

      <ul className="stack-legend" aria-label="What we build, layer by layer">
        {layers.map((l, i) => (
          <li key={l.name}>
            <button
              type="button"
              aria-pressed={active === i}
              onClick={() => pick(i)}
              onFocus={() => pick(i)}
              onMouseEnter={() => pick(i)}
            >
              <span className="mono">0{i + 1}</span>
              <span className="legend-name">{l.name}</span>
              <span className="legend-sub">{l.sub}</span>
              {active === i && (
                <motion.span layoutId="legend-active" className="legend-active" transition={{ type: "spring", stiffness: 300, damping: 30 }} />
              )}
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start start", "end start"] });
  const desktop = useMediaQuery("(min-width: 1024px)");
  const y = useTransform(scrollYProgress, [0, 1], [0, desktop ? 140 : 0]);
  const fade = useTransform(scrollYProgress, [0, 0.8], [1, desktop ? 0 : 1]);

  return (
    <section id="home" ref={ref} className="hero">
      <div className="hero-bg" aria-hidden="true">
        <div className="hero-grid-lines" />
        <div className="aurora aurora-a" />
        <div className="aurora aurora-b" />
        <div className="aurora aurora-c" />
      </div>

      <motion.div className="container hero-inner" style={{ y, opacity: fade }}>
        <div className="hero-copy">
          <motion.a
            href="#work"
            className="hero-badge"
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, ease, delay: 0.1 }}
          >
            <span className="pulse-dot" aria-hidden="true" />
            Independent development &amp; digital studio
            <ArrowUpRight size={14} className="opacity-60" />
          </motion.a>

          <h1 className="display-1">
            <RevealText text="Good ideas." className="block" delay={0.2} />
            <RevealText text="Great software." className="block" delay={0.35} />
            <RevealText text="Real possibilities." className="block serif-accent gradient-text" delay={0.5} />
          </h1>

          <motion.p
            className="hero-lead"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease, delay: 0.85 }}
          >
            We turn ambitious ideas into thoughtful websites, powerful
            applications, and campaigns that connect.
          </motion.p>

          <motion.div
            className="hero-actions"
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease, delay: 1 }}
          >
            <Magnetic>
              <a className="btn btn-primary btn-lg" href="#contact">
                Let’s build something
                <span className="btn-icon"><ArrowUpRight size={18} /></span>
              </a>
            </Magnetic>
            <a className="btn btn-ghost btn-lg" href="#work">
              Explore our work
            </a>
          </motion.div>
        </div>

        <motion.div
          className="hero-visual"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.2, ease, delay: 0.3 }}
        >
          <LayerStack />
        </motion.div>
      </motion.div>

      <motion.div
        className="container hero-bottom"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.3, duration: 1 }}
      >
        <span>Design with purpose</span>
        <span className="hero-bottom-line" aria-hidden="true" />
        <span>Develop with precision</span>
        <a href="#work" className="scroll-cue" aria-label="Scroll to selected work">
          <ArrowDown size={14} />
        </a>
      </motion.div>
    </section>
  );
}
