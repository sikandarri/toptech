import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { ArrowUpRight, CheckCircle2, ChevronDown, Globe2, Loader2 } from "lucide-react";
import { serviceOptions, budgetOptions, ease } from "../../data";
import { Eyebrow, FadeIn, RevealText } from "../ui/primitives";
import Spotlight from "../ui/Spotlight";

export default function Contact() {
  const [state, setState] = useState("idle");
  const [error, setError] = useState("");

  async function submit(e) {
    e.preventDefault();
    setState("sending");
    setError("");
    const form = e.currentTarget;
    const data = Object.fromEntries(new FormData(form));
    data.consent = Boolean(data.consent);
    try {
      const r = await fetch("/api/inquiries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const body = await r.json();
      if (!r.ok) throw new Error(body.message || "Please try again.");
      setState("success");
      form.reset();
    } catch (err) {
      setError(err.message);
      setState("idle");
    }
  }

  return (
    <section id="contact" className="section contact">
      <div className="contact-bg" aria-hidden="true" />
      <div className="container contact-grid">
        <div className="contact-copy">
          <Eyebrow>Let’s make it happen</Eyebrow>
          <h2 className="display-2 mt-6">
            <RevealText text="Your next big thing starts with" inView className="block" />
            <RevealText text="a conversation." inView delay={0.15} className="block serif-accent gradient-text" />
          </h2>
          <FadeIn delay={0.1}>
            <p className="section-lead">
              A new business, a better website, or an idea you can’t stop
              thinking about. Tell us what you have in mind.
            </p>
          </FadeIn>
          <FadeIn delay={0.2} className="contact-note">
            <span className="note-icon"><Globe2 size={20} /></span>
            <span>
              Based in Pakistan.
              <strong>Built for businesses everywhere.</strong>
            </span>
          </FadeIn>
        </div>

        <FadeIn delay={0.1} y={40}>
          <Spotlight as="form" onSubmit={submit} className="contact-form" size={480}>
            <div className="form-title">
              <span>Tell us about your project</span>
              <span className="mono text-fg/40">01 / Hello</span>
            </div>
            <div className="form-row">
              <label className="field">
                <span>Your name</span>
                <input name="name" autoComplete="name" required maxLength={100} placeholder="Alex Morgan" />
              </label>
              <label className="field">
                <span>Email address</span>
                <input name="email" type="email" autoComplete="email" required maxLength={254} placeholder="alex@company.com" />
              </label>
            </div>
            <div className="form-row">
              <label className="field">
                <span>What do you need?</span>
                <span className="select-wrap">
                  <select name="service">
                    {serviceOptions.map((o) => <option key={o}>{o}</option>)}
                  </select>
                  <ChevronDown size={16} aria-hidden="true" />
                </span>
              </label>
              <label className="field">
                <span>Budget range</span>
                <span className="select-wrap">
                  <select name="budget">
                    {budgetOptions.map((o) => <option key={o}>{o}</option>)}
                  </select>
                  <ChevronDown size={16} aria-hidden="true" />
                </span>
              </label>
            </div>
            <label className="field">
              <span>A little about your idea</span>
              <textarea
                required
                name="message"
                minLength={20}
                maxLength={5000}
                rows={4}
                placeholder="What are you building, and what would success look like?"
              />
            </label>
            <label className="honeypot" aria-hidden="true">
              Website
              <input name="website" tabIndex={-1} autoComplete="off" />
            </label>
            <label className="consent">
              <input required name="consent" type="checkbox" />
              <span>
                I agree to be contacted about this inquiry.{" "}
                <a href="#privacy">Privacy details</a>
              </span>
            </label>
            <button disabled={state === "sending"} className="btn btn-primary btn-lg submit">
              {state === "sending" ? "Sending your inquiry…" : "Let’s talk about your project"}
              <span className="btn-icon">
                {state === "sending" ? <Loader2 size={18} className="animate-spin" /> : <ArrowUpRight size={18} />}
              </span>
            </button>
            <div aria-live="polite">
              <AnimatePresence>
                {state === "success" && (
                  <motion.p
                    className="form-msg success"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    transition={{ ease }}
                  >
                    <CheckCircle2 size={18} /> Your inquiry is saved. Thank you for getting in touch.
                  </motion.p>
                )}
                {error && (
                  <motion.p
                    className="form-msg error"
                    role="alert"
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                  >
                    {error}
                  </motion.p>
                )}
              </AnimatePresence>
            </div>
          </Spotlight>
        </FadeIn>
      </div>
    </section>
  );
}
