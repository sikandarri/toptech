import { useState } from "react";
import { AnimatePresence, motion } from "motion/react";
import { Plus } from "lucide-react";
import { faqs, ease } from "../../data";
import { Eyebrow, FadeIn, RevealText } from "../ui/primitives";

export default function Faq() {
  const [open, setOpen] = useState(0);
  return (
    <section id="faq" className="section faq">
      <div className="container faq-grid">
        <div className="faq-side">
          <Eyebrow>A few good questions</Eyebrow>
          <h2 className="display-2 mt-6">
            <RevealText text="Before we" inView className="block" />
            <RevealText text="get started." inView delay={0.15} className="block serif-accent" />
          </h2>
          <p className="section-lead mt-6">
            Something else on your mind? <a href="#contact" className="underline-link">Ask us directly</a>.
          </p>
        </div>
        <div className="faq-list">
          {faqs.map(([q, a], i) => {
            const isOpen = open === i;
            return (
              <FadeIn key={q} delay={i * 0.05} className={`faq-item ${isOpen ? "is-open" : ""}`}>
                <h3>
                  <button
                    type="button"
                    aria-expanded={isOpen}
                    aria-controls={`faq-${i}`}
                    id={`faq-q-${i}`}
                    onClick={() => setOpen(isOpen ? -1 : i)}
                  >
                    <span className="mono text-fg/35">0{i + 1}</span>
                    <span className="flex-1">{q}</span>
                    <motion.span
                      className="faq-icon"
                      animate={{ rotate: isOpen ? 45 : 0 }}
                      transition={{ duration: 0.35, ease }}
                    >
                      <Plus size={18} />
                    </motion.span>
                  </button>
                </h3>
                <AnimatePresence initial={false}>
                  {isOpen && (
                    <motion.div
                      id={`faq-${i}`}
                      role="region"
                      aria-labelledby={`faq-q-${i}`}
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: "auto", opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.45, ease }}
                      className="overflow-hidden"
                    >
                      <p className="faq-answer">{a}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </FadeIn>
            );
          })}
        </div>
      </div>
    </section>
  );
}
