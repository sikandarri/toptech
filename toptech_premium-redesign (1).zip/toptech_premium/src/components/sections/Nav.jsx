import { useEffect, useState } from "react";
import { AnimatePresence, motion, useMotionValueEvent, useScroll } from "motion/react";
import { ArrowUpRight, Menu, X } from "lucide-react";
import { nav, ease } from "../../data";
import { useActiveSection } from "../../lib/hooks";
import { Brand, Magnetic } from "../ui/primitives";

const ids = nav.map(([, id]) => id);

export default function Nav({ lenis }) {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [hidden, setHidden] = useState(false);
  const active = useActiveSection(ids);
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (y) => {
    const prev = scrollY.getPrevious() ?? 0;
    setScrolled(y > 24);
    setHidden(y > 600 && y > prev + 4 && !open);
    if (y < prev - 4) setHidden(false);
  });

  useEffect(() => {
    if (!lenis) return;
    open ? lenis.stop() : lenis.start();
  }, [open, lenis]);

  useEffect(() => {
    const onKey = (e) => e.key === "Escape" && setOpen(false);
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <motion.header
        className="site-header"
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: hidden ? -110 : 0, opacity: 1 }}
        transition={{ duration: 0.6, ease }}
      >
        <div className={`nav-shell ${scrolled ? "is-scrolled" : ""}`}>
          <Brand />
          <nav aria-label="Main navigation" className="nav-links">
            {nav.map(([label, id]) => (
              <a key={id} href={`#${id}`} className={active === id ? "is-active" : ""}>
                {active === id && (
                  <motion.span
                    layoutId="nav-pill"
                    className="nav-pill"
                    transition={{ type: "spring", stiffness: 380, damping: 32 }}
                  />
                )}
                <span className="relative">{label}</span>
              </a>
            ))}
          </nav>
          <div className="nav-right">
            <div className="hidden md:block">
              <Magnetic>
                <a className="btn btn-primary btn-sm" href="#contact">
                  Start a project <ArrowUpRight size={16} />
                </a>
              </Magnetic>
            </div>
            <button
              className="menu-toggle"
              onClick={() => setOpen((o) => !o)}
              aria-label={open ? "Close navigation" : "Open navigation"}
              aria-expanded={open}
              aria-controls="mobile-menu"
            >
              {open ? <X size={20} /> : <Menu size={20} />}
            </button>
          </div>
        </div>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            id="mobile-menu"
            className="mobile-menu"
            initial={{ clipPath: "inset(0 0 100% 0)" }}
            animate={{ clipPath: "inset(0 0 0% 0)" }}
            exit={{ clipPath: "inset(0 0 100% 0)" }}
            transition={{ duration: 0.6, ease }}
          >
            <nav aria-label="Mobile navigation">
              {[...nav, ["Contact", "contact"]].map(([label, id], i) => (
                <motion.a
                  key={id}
                  href={`#${id}`}
                  onClick={() => setOpen(false)}
                  initial={{ y: 40, opacity: 0 }}
                  animate={{ y: 0, opacity: 1 }}
                  transition={{ delay: 0.15 + i * 0.06, duration: 0.6, ease }}
                >
                  <span className="mono text-xs text-fg/40">0{i + 1}</span>
                  {label}
                </motion.a>
              ))}
            </nav>
            <motion.p
              className="mono text-xs text-fg/50"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
            >
              PAKISTAN / WORKING WORLDWIDE
            </motion.p>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
