import { useRef } from "react";
import { motion, useScroll, useSpring } from "motion/react";
import { process, ease } from "../../data";
import { Eyebrow, FadeIn, ScrollWords, SectionHeading } from "../ui/primitives";

function Process() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ["start 0.85", "end 0.55"] });
  const scaleX = useSpring(scrollYProgress, { stiffness: 90, damping: 24 });
  return (
    <div ref={ref} className="process">
      <div className="process-track" aria-hidden="true">
        <motion.span style={{ scaleX }} />
      </div>
      <ol className="process-grid">
        {process.map(([t, d], i) => (
          <motion.li
            key={t}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 0.8, delay: i * 0.1, ease }}
          >
            <span className="process-node" aria-hidden="true" />
            <span className="process-no mono">Step 0{i + 1}</span>
            <h3>{t}</h3>
            <p>{d}</p>
          </motion.li>
        ))}
      </ol>
    </div>
  );
}

export default function Approach() {
  return (
    <section id="approach" className="section approach">
      <div className="container">
        <SectionHeading
          index="03"
          label="How we work"
          title="Less guesswork."
          accent="More getting it right."
          intro="You work directly with the person building your project. Clear conversations, considered decisions, and a plan you can follow."
        />
        <Process />

        <div className="founder">
          <FadeIn className="founder-card" y={40}>
            <div className="founder-mono" aria-hidden="true">
              <span>SI</span>
            </div>
            <div className="founder-id">
              <strong>Sikandar Iqbal</strong>
              <span>Founder, Top Tech Development</span>
            </div>
            <span className="founder-role mono">Developer / Founder</span>
          </FadeIn>
          <div className="founder-copy">
            <Eyebrow>A personal commitment</Eyebrow>
            <blockquote>
              <ScrollWords
                className="founder-quote"
                text="“Your business deserves more than another template.”"
              />
            </blockquote>
            <FadeIn delay={0.1}>
              <p className="section-lead">
                I’m Sikandar Iqbal, the developer behind Top Tech Development. I
                bring design, full-stack development, and advertising together
                to help businesses take their next step online.
              </p>
            </FadeIn>
          </div>
        </div>
      </div>
    </section>
  );
}
