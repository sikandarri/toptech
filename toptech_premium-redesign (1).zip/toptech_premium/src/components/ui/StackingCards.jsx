// Adapted from 21st.dev "Stacking Cards" by Khoa Phan (danielpetho registry).
// Cards pin as you scroll and gently scale back as the next one slides over.
import { createContext, useContext, useRef } from "react";
import { motion, useScroll, useTransform } from "motion/react";

const StackingCardsContext = createContext(null);

export default function StackingCards({
  children,
  className = "",
  totalCards,
  scaleMultiplier = 0.04,
  disabled = false,
  ...props
}) {
  const targetRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: targetRef,
    offset: ["start start", "end end"],
  });
  return (
    <StackingCardsContext.Provider
      value={{ progress: scrollYProgress, scaleMultiplier, totalCards, disabled }}
    >
      <div ref={targetRef} className={className} {...props}>
        {children}
      </div>
    </StackingCardsContext.Provider>
  );
}

export function StackingCardItem({ index, className = "", children, ...props }) {
  const ctx = useContext(StackingCardsContext);
  if (!ctx) throw new Error("StackingCardItem must be used within StackingCards");
  const { progress, scaleMultiplier, totalCards, disabled } = ctx;
  const scaleTo = 1 - (totalCards - index) * scaleMultiplier;
  const scale = useTransform(progress, [index / totalCards, 1], [1, scaleTo]);
  const dim = useTransform(progress, [index / totalCards, 1], [0, 0.5]);

  return (
    <div
      className={`stack-item ${className}`}
      style={{ "--i": index }}
      {...props}
    >
      <motion.div
        className="stack-item-inner"
        style={disabled ? undefined : { scale }}
      >
        {children}
        {!disabled && index < totalCards - 1 && (
          <motion.span
            aria-hidden="true"
            className="stack-item-dim"
            style={{ opacity: dim }}
          />
        )}
      </motion.div>
    </div>
  );
}
