// Adapted from 21st.dev "Spotlight" by kevingirelli.
// A soft light that follows the pointer across a surface and along its edge.
// Only two CSS variables update per frame, so nothing re-renders.
import { useEffect, useRef } from "react";

const RING_MASK =
  "linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0)";

export default function Spotlight({
  as: Comp = "div",
  size = 360,
  color = "#8b9dff",
  ring = true,
  className = "",
  children,
  onPointerMove,
  ...props
}) {
  const frame = useRef(0);
  useEffect(() => () => cancelAnimationFrame(frame.current), []);

  const circle = `${size}px circle at var(--spotlight-x, 50%) var(--spotlight-y, 50%)`;

  return (
    <Comp
      className={`spotlight group/spotlight relative isolate ${className}`}
      onPointerMove={(event) => {
        onPointerMove?.(event);
        if (event.pointerType === "touch") return;
        const target = event.currentTarget;
        const { clientX, clientY } = event;
        cancelAnimationFrame(frame.current);
        frame.current = requestAnimationFrame(() => {
          const b = target.getBoundingClientRect();
          target.style.setProperty("--spotlight-x", `${clientX - b.left}px`);
          target.style.setProperty("--spotlight-y", `${clientY - b.top}px`);
        });
      }}
      {...props}
    >
      <span
        aria-hidden="true"
        className="spotlight-light"
        style={{
          background: `radial-gradient(${circle}, color-mix(in oklab, ${color} 14%, transparent), transparent 70%)`,
        }}
      />
      {ring && (
        <span
          aria-hidden="true"
          className="spotlight-light spotlight-ring"
          style={{
            background: `radial-gradient(${circle}, color-mix(in oklab, ${color} 70%, transparent), transparent 60%)`,
            mask: RING_MASK,
            maskComposite: "exclude",
            WebkitMask: RING_MASK,
            WebkitMaskComposite: "xor",
          }}
        />
      )}
      {children}
    </Comp>
  );
}
