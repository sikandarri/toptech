import { Fragment, useRef } from "react";
import {
  motion,
  useMotionValue,
  useSpring,
  useScroll,
  useTransform,
} from "motion/react";
import { ease } from "../../data";

/** Pulls its child gently toward the pointer. Disabled on touch. */
export function Magnetic({ children, strength = 0.28, className = "" }) {
  const ref = useRef(null);
  const x = useSpring(useMotionValue(0), { stiffness: 220, damping: 18, mass: 0.4 });
  const y = useSpring(useMotionValue(0), { stiffness: 220, damping: 18, mass: 0.4 });
  return (
    <motion.span
      ref={ref}
      className={`inline-flex ${className}`}
      style={{ x, y }}
      onPointerMove={(e) => {
        if (e.pointerType === "touch") return;
        const b = ref.current.getBoundingClientRect();
        x.set((e.clientX - (b.left + b.width / 2)) * strength);
        y.set((e.clientY - (b.top + b.height / 2)) * strength);
      }}
      onPointerLeave={() => {
        x.set(0);
        y.set(0);
      }}
    >
      {children}
    </motion.span>
  );
}

/** Splits a line into words that rise out of a mask, staggered. */
export function RevealText({ text, className = "", delay = 0, as: Tag = "span", inView = false }) {
  const words = text.split(" ");
  const trigger = inView
    ? { initial: "hidden", whileInView: "show", viewport: { once: true, amount: 0.6 } }
    : { initial: "hidden", animate: "show" };
  return (
    <Tag className={className} aria-label={text}>
      <motion.span
        aria-hidden="true"
        className="inline"
        variants={{ show: { transition: { staggerChildren: 0.06, delayChildren: delay } } }}
        {...trigger}
      >
        {words.map((w, i) => (
          <Fragment key={i}>
            <span className="word-mask">
              <motion.span
                className="inline-block"
                variants={{
                  hidden: { y: "105%", opacity: 0, filter: "blur(8px)" },
                  show: {
                    y: "0%",
                    opacity: 1,
                    filter: "blur(0px)",
                    transition: { duration: 0.9, ease },
                  },
                }}
              >
                {w}
              </motion.span>
            </span>
            {i < words.length - 1 && " "}
          </Fragment>
        ))}
      </motion.span>
    </Tag>
  );
}

/** Words light up one by one as the paragraph scrolls through the viewport. */
export function ScrollWords({ text, className = "" }) {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start 0.85", "end 0.45"],
  });
  const words = text.split(" ");
  return (
    <p ref={ref} className={className} aria-label={text}>
      <span aria-hidden="true">
        {words.map((w, i) => (
          <Word key={i} progress={scrollYProgress} range={[i / words.length, (i + 1) / words.length]}>
            {w}
          </Word>
        ))}
      </span>
    </p>
  );
}
function Word({ children, progress, range }) {
  const opacity = useTransform(progress, range, [0.16, 1]);
  return (
    <>
      <motion.span style={{ opacity }}>{children}</motion.span>{" "}
    </>
  );
}

/** Fades and lifts content in when it enters the viewport. */
export function FadeIn({ children, delay = 0, y = 24, className = "", as = "div", ...props }) {
  const Comp = motion[as];
  return (
    <Comp
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.25 }}
      transition={{ duration: 0.8, delay, ease }}
      {...props}
    >
      {children}
    </Comp>
  );
}

export function Eyebrow({ children, className = "" }) {
  return (
    <p className={`eyebrow ${className}`}>
      <span className="eyebrow-dot" aria-hidden="true" />
      {children}
    </p>
  );
}

export function SectionHeading({ index, label, title, accent, intro, className = "" }) {
  return (
    <div className={`section-heading ${className}`}>
      <div>
        <Eyebrow>
          {index && <span className="text-fg/40">{index} — </span>}
          {label}
        </Eyebrow>
        <h2 className="display-2 mt-6">
          <RevealText text={title} inView className="block" />
          {accent && (
            <RevealText text={accent} inView delay={0.15} className="block serif-accent" />
          )}
        </h2>
      </div>
      {intro && (
        <FadeIn delay={0.2} className="section-intro">
          <p>{intro}</p>
        </FadeIn>
      )}
    </div>
  );
}

export function Brand({ className = "" }) {
  return (
    <a href="#home" className={`brand ${className}`} aria-label="Top Tech Development home">
      <span className="brandmark" aria-hidden="true">
        <svg viewBox="0 0 64 64" role="presentation" focusable="false">
          <defs>
            <linearGradient id="ttdMark" x1="10" y1="10" x2="54" y2="54" gradientUnits="userSpaceOnUse">
              <stop offset="0" stopColor="#3D7BFF" />
              <stop offset="0.58" stopColor="#7A5BC4" />
              <stop offset="1" stopColor="#9E7FD6" />
            </linearGradient>
          </defs>
          <path d="M11 15H35V22H27V49H19V22H11V15Z" fill="url(#ttdMark)" />
          <path d="M29 15H53V22H45V49H37V22H29V15Z" fill="url(#ttdMark)" opacity="0.9" />
          <path d="M24 31H40" stroke="#A8D5BA" strokeWidth="3" strokeLinecap="round" />
          <circle cx="50" cy="13" r="3.5" fill="#FF8A3D" />
        </svg>
      </span>
      <span className="brand-copy">
        <strong>Top Tech</strong>
        <span className="brand-sub">Development</span>
      </span>
    </a>
  );
}
