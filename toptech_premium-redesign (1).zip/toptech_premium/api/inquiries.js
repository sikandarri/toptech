import { handleInquiry } from "../server/inquiry.js";

// Vercel serverless function for POST /api/inquiries.
// The Express server in server/index.js does the same job on Hostinger.

const WINDOW_MS = 15 * 60 * 1000;
const LIMIT = 8;
// Best effort only: each serverless instance keeps its own counts. Add a
// Vercel Firewall rate-limit rule for /api/inquiries for a global limit.
const hits = new Map();

function rateLimited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter((t) => now - t < WINDOW_MS);
  recent.push(now);
  hits.set(ip, recent);
  if (hits.size > 5000) hits.clear();
  return recent.length > LIMIT;
}

export default async function handler(req, res) {
  res.setHeader("Cache-Control", "no-store");
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ message: "Method not allowed." });
  }
  if (Number(req.headers["content-length"] || 0) > 16 * 1024)
    return res.status(413).json({ message: "Request is too large." });

  const ip =
    req.headers["x-real-ip"] ||
    String(req.headers["x-forwarded-for"] || "").split(",")[0].trim() ||
    "unknown";
  if (rateLimited(ip))
    return res
      .status(429)
      .json({ message: "Too many inquiries. Please try again in 15 minutes." });

  let body = req.body;
  if (typeof body === "string") {
    try {
      body = JSON.parse(body);
    } catch {
      return res.status(400).json({ message: "Unable to process this request." });
    }
  }
  const result = await handleInquiry({ origin: req.headers.origin, body });
  return res.status(result.status).json(result.body);
}
