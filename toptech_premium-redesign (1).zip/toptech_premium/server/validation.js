import { z } from "zod";
export const inquirySchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(254),
  service: z.enum([
    "Website development",
    "Full-stack application",
    "E-commerce website",
    "Meta & Instagram ads",
    "Website + advertising",
  ]),
  budget: z.enum([
    "Let’s discuss",
    "Under PKR 100,000",
    "PKR 100,000–300,000",
    "PKR 300,000+",
  ]),
  message: z.string().trim().min(20).max(5000),
  consent: z.literal(true),
  website: z.string().max(0).optional(),
});
