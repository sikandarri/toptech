import "dotenv/config";
import mysql from "mysql2/promise";
let pool;
export function getPool() {
  if (!process.env.DB_HOST || !process.env.DB_NAME || !process.env.DB_USER)
    throw new Error("Database not configured");
  return (pool ??= mysql.createPool({
    host: process.env.DB_HOST,
    port: Number(process.env.DB_PORT || 3306),
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    // Serverless instances each hold their own pool, so keep them small on Vercel.
    connectionLimit: process.env.VERCEL ? 2 : 5,
    maxIdle: process.env.VERCEL ? 1 : 5,
    idleTimeout: 60000,
    enableKeepAlive: true,
    waitForConnections: true,
    queueLimit: 20,
    connectTimeout: 10000,
    charset: "utf8mb4",
    ...(process.env.DB_SSL === "true"
      ? { ssl: { rejectUnauthorized: true } }
      : {}),
  }));
}
