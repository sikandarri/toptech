import { getPool } from "./db.js";
import { inquirySchema } from "./validation.js";

// Shared by the Express server (Hostinger) and the Vercel function in api/.
// Returns { status, body } so each runtime can send it its own way.

export function isAllowedOrigin(origin) {
  if (!origin || !process.env.PUBLIC_ORIGIN) return true;
  const allowed = [process.env.PUBLIC_ORIGIN];
  // Vercel preview and deployment URLs should be able to submit to themselves.
  if (process.env.VERCEL_URL) allowed.push(`https://${process.env.VERCEL_URL}`);
  if (process.env.VERCEL_BRANCH_URL)
    allowed.push(`https://${process.env.VERCEL_BRANCH_URL}`);
  return allowed.includes(origin);
}

export async function handleInquiry({ origin, body }) {
  if (!isAllowedOrigin(origin))
    return { status: 403, body: { message: "This request is not allowed." } };
  const parsed = inquirySchema.safeParse(body);
  if (!parsed.success)
    return {
      status: 400,
      body: {
        message:
          "Please provide a valid name and email, at least 20 characters about your project, and consent to be contacted.",
      },
    };
  const { name, email, service, budget, message } = parsed.data;
  try {
    const pool = getPool();
    await pool.execute(
      "INSERT INTO inquiries (name,email,service,budget,message,consent) VALUES (?,?,?,?,?,?)",
      [name, email, service, budget, message, true],
    );
    return { status: 201, body: { message: "Inquiry saved." } };
  } catch (err) {
    console.error("Inquiry persistence unavailable:", err.code || err.message);
    return {
      status: 503,
      body: {
        message:
          "The inquiry service is temporarily unavailable. Please try again later.",
      },
    };
  }
}
