import test from "node:test";
import assert from "node:assert/strict";
import { inquirySchema } from "./validation.js";
const valid = {
  name: "Test Customer",
  email: "test@example.com",
  service: "Website development",
  budget: "Let’s discuss",
  message: "A new website for my small business.",
  consent: true,
  website: "",
};
test("accepts complete inquiries and trims input", () => {
  const result = inquirySchema.parse({ ...valid, name: "  Test Customer  " });
  assert.equal(result.name, "Test Customer");
});
test("rejects malformed emails, missing consent, short messages and bots", () => {
  for (const change of [
    { email: "bad" },
    { consent: false },
    { message: "Hi" },
    { website: "https://spam.example" },
    { name: "a" },
    { service: "arbitrary" },
    { message: "x".repeat(5001) },
  ])
    assert.equal(
      inquirySchema.safeParse({ ...valid, ...change }).success,
      false,
    );
});
