import "dotenv/config";
import express from "express";
import helmet from "helmet";
import { rateLimit } from "express-rate-limit";
import { fileURLToPath } from "node:url";
import path from "node:path";
import fs from "node:fs";
import { handleInquiry } from "./inquiry.js";
const app = express();
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
if (process.env.TRUST_PROXY_HOPS)
  app.set("trust proxy", Number(process.env.TRUST_PROXY_HOPS));
app.disable("x-powered-by");
app.use(
  helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'"],
        styleSrc: ["'self'", "'unsafe-inline'"],
        imgSrc: ["'self'", "data:", "https://image.thum.io", "https://s.wordpress.com", "https://s0.wp.com"],
        connectSrc: ["'self'"],
        fontSrc: ["'self'"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
        upgradeInsecureRequests:
          process.env.NODE_ENV === "production" ? [] : null,
      },
    },
  }),
);
app.use(express.json({ limit: "16kb" }));
app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
app.post(
  "/api/inquiries",
  rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 8,
    standardHeaders: "draft-7",
    legacyHeaders: false,
    message: { message: "Too many inquiries. Please try again in 15 minutes." },
  }),
  async (req, res) => {
    const result = await handleInquiry({
      origin: req.get("origin"),
      body: req.body,
    });
    return res.status(result.status).json(result.body);
  },
);
app.use("/api", (_req, res) => res.status(404).json({ message: "Not found." }));
const dist = path.join(root, "dist");
if (fs.existsSync(dist)) {
  app.use(
    express.static(dist, {
      maxAge: "1h",
      setHeaders(res, file) {
        if (file.includes(`${path.sep}assets${path.sep}`))
          res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
        if (file.endsWith("index.html"))
          res.setHeader("Cache-Control", "no-cache");
      },
    }),
  );
  app.get("/{*path}", (_req, res) =>
    res.sendFile(path.join(dist, "index.html")),
  );
}
app.use((err, _req, res, _next) =>
  res
    .status(err.status === 413 ? 413 : 400)
    .json({
      message:
        err.status === 413
          ? "Request is too large."
          : "Unable to process this request.",
    }),
);
const port = Number(process.env.PORT || 3000);
app.listen(port, "0.0.0.0", () =>
  console.log(`Top Tech Development running on port ${port}`),
);
